#include <Timer.h>

Timer::Timer(uint32_t cooldown) {

	_time = millis();
	_cooldown = cooldown;

};

bool Timer::get() {

	if (millis() - _time >= _cooldown) {

		_time = millis();
		return true;

	}

	return false;
	
};

bool Timer::get(uint32_t cooldown) {

	if (millis() - _time >= cooldown) {

		_time = millis();
		return true;

	}

	return false;
	
};